fx_version 'bodacious'
game 'gta5'
lua54 'yes'

author 'FM'
description 'SHOWROOM'

this_is_a_map 'yes'

data_file 'TIMECYCLEMOD_FILE' 'fm_timecycle_list_showroom.xml'
data_file 'DLC_ITYP_REQUEST' 'stream/**.ytyp'

files {
    'fm_timecycle_list_showroom.xml',
    'stream/**.ytyp',

}
